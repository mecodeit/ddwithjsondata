var app = angular.module('app', ['ngTouch', 'ui.grid', 'ui.grid.edit']);

app.controller('MainCtrl', ['$scope', '$http', function($scope, $http) {
  $scope.gridOptions = {};

  $scope.gridOptions.columnDefs = [{
      name: 'id',
      enableCellEdit: false,
      width: '10%'
    }, {
      name: 'name',
      displayName: 'Name (editable)',
      width: '20%'
    }, {
      name: 'age',
      displayName: 'Age',
      type: 'number',
      width: '10%'
    }, {
      name: 'gender',
      displayName: 'Gender',
      editableCellTemplate: 'ui-grid/dropdownEditor',
      width: '20%',
      cellFilter: 'mapGender',
      editDropdownValueLabel: 'gender',
      editDropdownOptionsArray: [{
        id: 'male',
        gender: 'Male'
      }, {
        id: 'female',
        gender: 'Female'
      }]
    }, {
      name: 'registered',
      displayName: 'Registered',
      type: 'date',
      cellFilter: 'date:"yyyy-MM-dd"',
      width: '20%'
    },

  ];

  $scope.msg = {};

  $scope.gridOptions.onRegisterApi = function(gridApi) {
    //set gridApi on scope
    $scope.gridApi = gridApi;
    gridApi.edit.on.afterCellEdit($scope, function(rowEntity, colDef, newValue, oldValue) {
      $scope.msg.lastCellEdited = 'edited row id:' + rowEntity.id + ' Column:' + colDef.name + ' newValue:' + newValue + ' oldValue:' + oldValue;
      $scope.$apply();
    });
  };

  $http.get('https://cdn.rawgit.com/angular-ui/ui-grid.info/gh-pages/data/500_complex.json')
    .success(function(data) {
      $scope.gridOptions.data = data;
    });
}])

.filter('mapGender', function() {
  var genderHash = {
    'male': 'Male',
    'female': 'Female'
  };

  return function(input) {
    if (!input) {
      return '';
    } else {
      return genderHash[input];
    }
  };
});